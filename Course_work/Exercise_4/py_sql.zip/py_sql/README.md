# Simple SQL Injection CTF

## Build Docker Container
docker build -t sql_ctf .

## Run Container
docker run -p 8080:8080 sql_ctf

## Access the Challenge
Open http://localhost:8080 in a browser.
